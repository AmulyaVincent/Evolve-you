import React from 'react';
import "./PrivacyPolicy.css";

function PrivacyPolicy() {
  return (
    <div className='privacy'>
      <div className='privacy-heading'>
      <h1> PRIVACY POLICY</h1>
      </div>
      <p>We ask that you read this website privacy policy carefully as it contains important information on who we are, how and why we collect, store, use and share personal information, your rights in relation to your personal information and on how to contact us and supervisory authorities in the event you have a complaint.</p>
        <p>These terms and conditions of use (Terms) explain how you may use this website (www.evolveyou.app) (SiteA) or our mobile application (App) and any of its content. These Terms apply between EvolveYou App Limited trading as EvolveYou (we, us or our) and you, the person accessing or using the Site or our App (you or your).You should read these Terms carefully before using the Site or App. By using the Site or App or otherwise indicating your consent, you agree to be bound by these Terms. If you do not agree with any of these Terms, you should stop using the Site or App immediately.</p>
        <h2>About Us</h2>
        <p>We are EvolveYou App Limited, a company registered in England and Wales under company registration number 10591766. Our registered office is at Langley House, Park Road, London, N2 8EY. Our VAT registration number is GB266057591.</p>
        <p>We collect, use and are responsible for certain personal data about you. When we do so we are subject to the UK General Data Protection Regulation (UK GDPR). We are also subject to the EU General Data Protection Regulation (EU GDPR) in relation to goods and services we offer to individuals and our wider operations in the European Economic Area (EEA).</p>
        <h3>Our Website and Mobile Application</h3>
        <p>This privacy policy relates to your use of our website, evolveyou.app and mobile application.</p>
        <p>Our Site and App may include links to third-party websites, plug-ins and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements. When you leave our Site or App, we encourage you to read the privacy notice of every website you visit.</p>
    </div>
)
}

export default PrivacyPolicy
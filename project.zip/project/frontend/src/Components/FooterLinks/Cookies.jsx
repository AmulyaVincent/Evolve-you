import React from 'react'
import "./Cookies.css";

function Cookies() {
  return (
    <div className='cookies'>
      <div className='cookies-heading'>
      <h1> COOKIE POLICY</h1>
      </div>
      <p>EvolveYou (“us", "we", or "our") uses cookies on EvolveYou (the "Service"). By using the Service, you consent to the use of cookies.Our Cookies Policy explains what cookies are, how we use cookies, how third-parties we may partner with may use cookies on the Service, your choices regarding cookies and further information about cookies.</p>
        <h2>What are cookies</h2>
        <p>Cookies are small pieces of text sent by your web browser by a website you visit. A cookie file is stored in your web browser and allows the Service or a third-party to recognize you and make your next visit easier and the Service more useful to you.
Cookies can be "persistent" or "session" cookies.</p>
        <p>When you use and access the Service, we may place a number of cookies files in your web browser.We use cookies for the following purposes: to enable certain functions of the Service, to provide analytics, to store your preferences, to enable advertisements delivery, including behavioral advertising.</p>
        <h3>Third-party cookies</h3>
        <p>In addition to our own cookies, we may also use various third-parties cookies to report usage statistics of the Service, deliver advertisements on and through the Service, and so on.</p>
        <p>When opting into our Referral Platform provided by Mention Me Ltd we also use essential cookies in order to accurately track referrals made by users to generate rewards. Further information on how these cookies are used can be found here https://mention-me.com/help/privacy_policy_s#cookies.</p>  </div>
  )
}

export default Cookies
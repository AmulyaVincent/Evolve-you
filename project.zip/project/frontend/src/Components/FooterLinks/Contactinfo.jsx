import React from 'react';
import "./Contactinfo.css";

function Contactinfo() {
  return (
    <div className='contactinfo'>
    <div className='contact-heading'>
    <h1> CONTACT DETAILS</h1>
    </div>
    <h3>Get in Touch!</h3>
    <p>We at EvolveYou are always eager to hear from you. Whether you’re looking to start your fitness journey, have questions about our platform, or simply want to share your transformative experiences, we’re here for you. Reach out to us, and let’s embark on a path to greater strength and confidence together. We’ve got this!</p>
    <p>Remember to include actual contact information such as an email address, phone number, or a contact form link in your contact details page.</p>
     <div className='info'>
     <p>EVOLVE-YOU</p>
     <p>Evolve-you@gmail.com</p>
     <p>Contact: +91 9866098379</p>
     </div>
     </div>
  )
}

export default Contactinfo;
import "./Videos.css";
import YoutubeEmbed from "./YoutubeEmbed";

function Workouts() {
  return (
    <div className="workouts">
      <h4>Break a sweat with these popular workouts.</h4>
      <div className="workoutcards">
      <YoutubeEmbed embedId="2pLT-olgUJs"/>
      <YoutubeEmbed embedId="W4eKVKwf3rQ"/>
      <YoutubeEmbed embedId="GViX8riaHX4"/>
      </div>

    </div>
  );
}

export default Workouts;

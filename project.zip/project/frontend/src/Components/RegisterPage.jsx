import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import backgroundImage from "../Assets/1.jpg";
import "./Register.css";
import validator from 'validator'; // Add this line

function Registerpage() {
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [confirmPassword, setConfirmPassword] = useState();
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    
    if (!validator.isEmail(email)) {
      alert("Please enter a valid email!");
      return;
    }

    localStorage.setItem('name', name);
    localStorage.setItem('email', email);

    axios.post("http://localhost:3001/register", { name, email, password })
      .then((result) => {
        console.log(result);
        if (result.data === "Already registered") {
          alert("E-mail already registered! Please Login to proceed.");
          navigate("/login");
        } else {
          alert("Registered successfully! Please Login to proceed.");
          navigate("/login");
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="register-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <form onSubmit={handleSubmit}>
        <label>Name</label>
        <input
          type="text"
          placeholder="Enter name.."
          onChange={(e) => setName(e.target.value)}
          required
        />
        <label>Email</label>
        <input
          type="email"
          placeholder="Enter email.."
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label>Create Password</label>
        <input
          type="password"
          placeholder="Enter password.."
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <label>Confirm Password</label>
        <input
          type="password"
          placeholder="Confirm password.."
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button className="register-btn" type="submit" onClick={handleSubmit}>Register</button>
      </form>
    </div>
  );
}

export default Registerpage;

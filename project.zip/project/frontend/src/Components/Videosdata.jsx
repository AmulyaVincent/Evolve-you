import "./Videos.css";
import YoutubeEmbed from "./YoutubeEmbed";

function VideosData(props) {
  return (
    <div className="w-card">
        <YoutubeEmbed>{props.embedId}</YoutubeEmbed>
    </div>
  );
}

export default VideosData;

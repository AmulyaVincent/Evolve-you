import React from "react";
import "./Training.css";
import { Link } from "react-router-dom";
import { Data } from "./Data";

function Training() {
  const status = localStorage.getItem("status");

  const handleViewCourse = (id) => {
    if (status === "true") {
      window.location.href = `/workout/${id}`;
    } else {
      alert("Please log in to view details");
      window.location.href = "/login";
    }
  };
  return (
    <div className="trainintro">
      <h1>Training Courses</h1>
      <p>
        Elevate your health journey one delicious bite at a time with our
        nutritious and satisfying recipes.
      </p>
      <div className="train-container">
        {Data.map((eachCourse) => {
          const { id, title, image, text } = eachCourse;
          return (
            <article className="t-card">
              <div className="t-image">
                <img src={image} alt={title} />
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
              <Link to={`/workout/${id}`} key={id}>
                 <button className="card-btn" onClick={() => handleViewCourse(id)}>
                View Course
              </button>
              </Link>
            </article>
          );
        })}
      </div>
    </div>
  );
}

export default Training;

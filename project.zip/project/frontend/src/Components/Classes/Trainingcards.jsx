import React from "react";
import { useParams , Link } from "react-router-dom";
import { Data } from "./Data";
import "./TrainingCards.css";
import YoutubeEmbed from "../../Components/YoutubeEmbed";
import Navbar from "../NavBar/Navbar";

function TrainingCards() {
  const { CourseId } = useParams();

  const TrainingData = Data.find(
    (eachCourse) => String(eachCourse.id) === CourseId
  );

  return (
    <>
      <Navbar />
      <div className="training-card">
        
        <div className="workout-course">
          <h1>Online  Sessions</h1>
  
          <h3>{TrainingData.title}</h3>
          <Link to="/workout">
            <button className="course-btn">Back</button>
          </Link>
          
 
          <p>{TrainingData.text}</p>
          <div className="course-cards">
            {TrainingData.videos.map((videos, index) => (
              <YoutubeEmbed key={index} embedId={videos} />
            ))}
          </div>

        </div>
      </div>
    </>
  );
}

export default TrainingCards;

import abs from "../../Assets/Abs.jpg";
import legs from "../../Assets/legs.jpg";
import hiit from "../../Assets/hiit.jpg";
import abs1 from "../../Assets/shreddedabs.jpg";
import upperbody from "../../Assets/upperbody.jpg";
import yoga from "../../Assets/yoga.jpg";

export const Data =[
  {
    id:1,
    title:"Abs Workout",
    image:abs,
    payment:"$10",
    text:"Abdominal exercises target these back muscles and the spine. These workouts also improve body posture thus reducing the back pain associated with poor posture.",
    videos:[
      "2pLT-olgUJs",
      "rptV4dEJUx4",
      "vOiP3kfFlrE",
      "t7Fn8M81deE",
      "QKCkO9fy9O4",
      "Th97oQ4eF9U",
      "3yL0klflL0M",
      "RVrxNf4dtO4",
      "lCrDZ5YR_7E",
    ]
  },
  {
    id:2,
    title:"Legs Workout",
    image:hiit,
    payment:"$10",
    text:"Having toned legs is a goal of many people. Our experience is that while men prefer to have muscular size, women tend to prefer to show tone and subtle definition",
    videos:[
      "1IQGtcv3eRY",
      "2_lCvBvHRFI",
      "EagY20j2tyw",
      "074eiXBWpm4",
      "EUruBzhv7Kk",
      "kcZ7K8MmRiQ",
      "pfSG4PpxGl4",
      "WemFH7Mwo98",
      "uVwNVEQS_uo",
    ]
  },
  {
    id:3,
    title:"Yoga",
    image:legs,
    payment:"$10",
    text:"Yoga incorporates breath control and meditation.The health benefits of yoga practice may include lowering blood pressure, posture, and a sense of wellbeing.",
    videos:[
      "brjAjq4zEIE",
      "iWUaZfR-gWU",
      "gXuq4M5rU9E",
      "QrkfpGv0MFY",
      "yRCUfumiqhk",
      "oyzWgjDPn6Q",
      "unHtr1jgPkg",
      "CbQ2hsiEeYc",
      "XwC7MDDsbDs",
    ]
  },
  {
    id:4,
    title:" Warm-up",
    image:abs1,
    payment:"$10",
    text:"The purpose of warming up before physical activity is to prepare mentally and physically for your chosen activity. Warming up increases your heart rate.",
    videos:[
      "-p0PA9Zt8zk",
      "f3zOrYCwquE",
      "GsFOq_gBQfI",
      "BSh4zJHVxs0",
      "p7EU5yGAcJ4",
      "jkv-RMuigaA",
      "iGv_XEW9b9M",
      "QZCzAXksaTc",
      "72MQmD8Z9Zw",
    ]
  },
  {
    id:5,
    title:"Upper-Body",
    image:upperbody,
    payment:"$10",
    text:"Having firm upper body is a goal of many people. Our experience is that while men prefer to have muscular size, women tend to prefer to show tone and subtle definition",
    videos:[
      "WGA_ctAMkMk",
      "4JnkcAUq4Ss",
      "ESkI_WR1qqc",
      "7L-Td_p0bXE",
      "DHOPWvO3ZcI",
      "e_HviaEIEas",
      "Ay2JDmOM5tU",
      "7AuskEkSi30",
      "Q98t9cbp-xo",
    ]
  },
  {
    id:6,
    title:"Full-Body",
    image:yoga,
    payment:"$10",
    text:"Having fit body is a goal of many people. Our experience is that while men prefer to have muscular size, women tend to prefer to show tone and subtle definition",
    videos:[
      "cbKkB3POqaY",
      "ge1ALhE-Fqs",
      "W4eKVKwf3rQ",
      "NQmnJtB1gzo",
      "ljNgkSctkXg",
      "9FBIaqr7TjQ",
      "Urx4gMA2-Kw",
      "Wgm1Xc25imM",
      "ESPWlnCIoaQ",
    ]
  }
]
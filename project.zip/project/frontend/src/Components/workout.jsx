import "./workout.css";
import WorkoutData from "./Workoutdata";
import abs from "../Assets/Abs.jpg";
import legs from "../Assets/legs.jpg";
import hiit from "../Assets/hiit.jpg";

function Workout() {
  return (
    <div className="workout">
      <h1>Training Courses</h1>
      <p>Break a sweat with these popular workouts.</p>
      <div className="workoutcard">
        <WorkoutData
          url="/workout"
          image={abs}
          heading=" Abs workout Video"
          text="Want more-defined stomach muscles? Core exercises
         are important. While it takes aerobic activity to burn
          fat in your stomach,core exercises can strengthen and tone 
          the underlying muscles."
        />
        <WorkoutData
          image={legs}
          url="/workout"
          heading="Toned legs workout Video"
          text="Having toned legs is a goal of many people. Our experience
         is that while men prefer to have muscular size, women tend to prefer
          to show tone and subtle definition."
        />
        <WorkoutData
          image={hiit}
          url="/workout"
          heading=" Full Body HIIT workout"
          text="High-intensity interval training (HIIT) is a training protocol 
        alternating short periods of intense or explosive anaerobic exercise 
        with brief recovery periods until the point of exhaustion."
        />
      </div>
    </div>
  );
}

export default Workout;

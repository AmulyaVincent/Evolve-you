import React from 'react';
import './ContactFormStyles.css';
import { useState } from 'react';
import axios from 'axios';
 
const ContactForm = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
   
    const handleSubmit = (event) => {
        event.preventDefault();
       
        axios.post( 'http://localhost:3001/contactus', {name, email, message})
        .then(result => {
            console.log(result);
            setName("");
            setEmail("");
            setMessage("");
            alert("You query has been sent");
        })
        .catch(err => console.log(err));
    }
 
    return (
        <div className="contact-container">
            <p>If you have any questions or suggestions about the Workouts or Recipes, feel free to reach out to us. We'd love to hear from you!</p>
           
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Name:</label>
                <input type="text" id="name" name="name" value={name} onChange={(event) => setName(event.target.value)} required />
 
                <label htmlFor="email">Email:</label>
                <input type="email" id="email" name="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
 
                <label htmlFor="message">Message:</label>
                <textarea id="message" name="message" value={message} onChange={(event) => setMessage(event.target.value)} required></textarea>
 
                <input type="submit" value="Submit" />
            </form>
        </div>
    );
}
 
export default ContactForm;
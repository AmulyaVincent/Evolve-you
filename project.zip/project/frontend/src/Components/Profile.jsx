import React, { useState, useEffect } from "react";
import axios from "axios";
import nouser from "../Assets/nouser.jpg";
import { useNavigate } from "react-router-dom";
import "./Profile.css";

export const Profile = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [name,setName]= useState('');
  const [userimage, setUserImage] = useState();

  useEffect(() => {
    setName(localStorage.getItem('name') || '');
    setEmail(localStorage.getItem('email') || '');
    const savedImage = localStorage.getItem(email);
    if (savedImage) {
      setUserImage(savedImage);
    }
  }, []);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setUserImage(reader.result);
      localStorage.setItem(email, reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="profile">
      <h1>Account</h1>
      <div className="pImg">
        {userimage ? (
          <img
            className="userimg"
            src={userimage}
            alt="userimage"
          />
        ) : (
          <img className="userimg" src={nouser} alt="nouser" />
        )}
      </div>
      <input
        type="file"
        onChange={handleImageChange}
        className="file"
      />
      <p>UserName: {name}</p>
      <p>Email: {email}</p>

      <button onClick={() => navigate("/")}>Back To Home Page</button>
    </div>
  );
};

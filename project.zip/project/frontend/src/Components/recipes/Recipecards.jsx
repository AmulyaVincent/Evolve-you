import React from "react";
import { useParams } from "react-router-dom";
import { Recipedata } from "./Recipedata";
import "./RecipeCards.css";
import { Link } from "react-router-dom";

function Recipecards() {
  const { RecipeId } = useParams();
  const RecipeDetailsData = Recipedata.find(
    (eachRecipe) => String(eachRecipe.id) === RecipeId
  );

  return (
    <div className="instructions">
      <Link to="/recipes">
        <button className="recipe-btn">Back to Recipes</button>
      </Link>
      <h3 className="title">{RecipeDetailsData.title}</h3>
      <div className="recipe-image">
        <img className="picture" src={RecipeDetailsData.image} />
      </div>
      <div className="recipe-content">
        <h3>Ingredients</h3>
        <ul className="recipe-ingredients">
          {RecipeDetailsData.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))}
        </ul>
        <h3>Instructions</h3>
        <ol>
          {RecipeDetailsData.instructions.map((instruction, index) => (
            <li className="instruction-list" key={index}>
              {instruction}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

export default Recipecards;

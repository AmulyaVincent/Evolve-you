import React from "react";
import "./Recipe.css";
import { Link } from "react-router-dom";
import { Recipedata } from "./Recipedata";

function RecipeItem() {
  const status = localStorage.getItem("status");

  const handleViewRecipe = (id) => {
    if (status === "true") {
      window.location.href = `/recipe/${id}`;
    } else {
      alert("Please log in to view details");
      window.location.href = "/login";
    }
  };

  return (
    <div className="recipeintro">
      <h1>Healthy Recipes</h1>
      <p>
        Elevate your health journey one delicious bite at a time with our
        nutritious and satisfying recipes.
      </p>
      <div className="card-container">
        {Recipedata.map((eachRecipe) => {
          const { id, title, image, content } = eachRecipe;
          return (
            <article className="card" key={id}>
              <div className="r-image">
                <img src={image} alt={title} />
              </div>
              <h3>{title}</h3>
              <p>{content}</p>
              <button
                className="recipes-card"
                onClick={() => handleViewRecipe(id)}
              >
                View Recipe
              </button>
            </article>
          );
        })}
      </div>
    </div>
  );
}

export default RecipeItem;

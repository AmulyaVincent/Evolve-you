import "./hlifestyle.css";
import hlifestyle from "../Assets/healthylifestyle.jpg";

const Hlifestyle = () => {
  return (
    <div className="pic">
      <img src={hlifestyle} alt="pic"></img>
    </div>
  );
};
export default Hlifestyle;

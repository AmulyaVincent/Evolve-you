import "./FooterStyles.css";

const Footer = () => {
  return (
    <div className="footer">
      <div className="top">
        <div>
          <h1>Evolve You</h1>
          <p>Feel the difference</p>
        </div>
        <div>
          <a href="/https://www.facebook.com/">
            <i className="fa-brands fa-facebook-square"></i>
          </a>
          <a href="/https://www.instagram.com/">
            <i className="fa-brands fa-instagram-square"></i>
          </a>
          <a href="/https://www.behance.net/">
            <i className="fa-brands fa-behance-square"></i>
          </a>
          <a href="/https://twitter.com/?lang=en-in">
            <i className="fa-brands fa-twitter-square"></i>
          </a>
        </div>
      </div>
      <div className="bottom">
        <div>
          <h4>Project</h4>
          <a href="/">Home</a>
          <a href="/workout">Workouts</a>
          <a href="/recipe">Recipes</a>
          <a href="/login">Sign-Up</a>
        </div>
        <div>
          <h4>Community</h4>
          <a href="/https://github.com/">Github</a>
          <a href="/">About Us</a>
          <a href="/PrivacyPolicy">Project</a>
          <a href="/https://twitter.com/?lang=en-in">Twitter</a>
        </div>
        <div>
          <h4>Help</h4>
          <a href="/Cookies">Cookies</a>
          <a href="/PrivacyPolicy">Privacy Policy</a>
          <a href="/Contactinfo">Contact Us</a>
        </div>
        <div>
          <h4>Contact Information</h4>
          <a href="/">Evolve-You</a>
          <a href="/">Contact:+91 9866098379</a>
          <a href="/">Email:Evolve-you@gmail.com</a>
        </div>
      </div>
    </div>
  );
};

export default Footer;

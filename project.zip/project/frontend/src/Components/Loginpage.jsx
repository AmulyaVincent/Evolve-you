import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import backgroundImage from "../Assets/logincard.jpg";
import "./login.css";


function Login() {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    axios
      .post("http://127.0.0.1:3001/login", { email, password })
      .then((result) => {
        console.log(result);
        if (result.data.success) {
          localStorage.setItem('name', result.data.user.name);
          localStorage.setItem('email', result.data.user.email);
          localStorage.setItem("status",true);
          console.log("Login Success");
          alert("Login successful!");
          navigate("/");
          
        } else {
          alert("Incorrect password! Please try again.");
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="form-container" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <form onSubmit={handleSubmit}>
        <label>Email</label>
        <input
          type="email"
          placeholder="Enter email.."
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label>Password</label>
        <input
          type="password"
          placeholder="Enter password.."
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button className="login-btn" type="submit">Login</button>
        <p></p>
        <p>
          Not a User? <Link to="/RegisterPage"> Register here </Link>
        </p>
      </form>
    </div>
  );
}

export default Login;

 import "./BenefitStyles.css";
import BenefitsData from "./BenefitsData";
import Healthy1 from "../Assets/healthy.jpg";
import Healthy2 from "../Assets/meditate.jpg";
import goal1 from "../Assets/goal1.jpg";
import goal2 from "../Assets/goal2.jpg";
import Strength1 from "../Assets/strength1.jpg";
import Strength2 from "../Assets/strength2.jpg";

const Benefits = () => {
  return (
    <div className="benefit">
      <h1>Fitness Benfits</h1>
      <p>Feel the differnce and make yourself feel better</p>
      <BenefitsData
        heading="Jump into a healthier lifestyle"
        text=" Whether you’re a beginner or just need a little extra motivation,
      the MadFit app has all the tools you need to get started on a
      healthier lifestyle right at your fingertips.Whether you’re a
      beginner or just need a little extra motivation, the MadFit app has
      all the tools you need to get started on a healthier lifestyle right
      at your fingertips."
        img1={Healthy1}
        img2={Healthy2}
      />

      <BenefitsData
        heading="Fuel your
        goals"
        text=" Hundreds of tasty and healthy recipes with enough variety to suit any diet. 
        You can find plenty of wholesome ways to give your body the nutrients it needs to
         power your fitness journey.Hundreds of tasty and healthy recipes with enough variety to suit any diet.
          You can find plenty of wholesome ways to give your body the nutrients it needs to power your fitness journey."
        img1={goal1}
        img2={goal2}
      />

      <BenefitsData
        heading="Strengthen and
        tone your body"
        text="Structured workout programs, challenges and a huge collection of 
        real-time videos will ensure you always have something new to challenge 
        yourself with.Structured workout programs, challenges and a huge collection 
        of real-time videos will ensure you always have something new to challenge yourself with.
        Structured workout programs, challenges and a huge collection of real-time videos will ensure
         you always have something new to challenge yourself with."
        img1={Strength1}
        img2={Strength2}
      />
    </div>
  );
};

export default Benefits;

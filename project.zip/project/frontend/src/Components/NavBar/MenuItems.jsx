export const MenuItems = [
  {
    title: "Home",
    url: "/",
    cName: "nav-links",
    icon: "fa-solid fa-house-user",
  },

  {
    title: "Workouts",
    url: "/workout",
    cName: "nav-links",
    icon: "fa-solid fa-dumbbell",
  },
  ,
  {
    title: "Recipes",
    url: "/recipes",
    cName: "nav-links",
    icon: "fa-solid fa-bowl-food",
  },

  {
    title: "Contact",
    url: "/contactus",
    cName: "nav-links",
    icon: "fa-solid fa-phone",
  },
];

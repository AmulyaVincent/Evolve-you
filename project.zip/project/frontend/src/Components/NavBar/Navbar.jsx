import { Component } from "react";
import "./NavbarStyles.css";
import { MenuItems } from "./MenuItems";
import { NavLink, Link, useLocation } from "react-router-dom";

class Navbar extends Component {
  state = {
    clicked: false,
    isLoggedIn: false,
  };

  componentDidMount() {
    const status = localStorage.getItem("status");
    this.setState({ isLoggedIn: status ? true : false });
  }

  handleClick = () => {
    this.setState({ clicked: !this.state.clicked });
  };

  login = () => {
    localStorage.setItem("status", "loggedIn");
    this.setState({ isLoggedIn: true });
  };

  logout = () => {
    localStorage.removeItem("status");
    localStorage.removeItem("name");
    localStorage.removeItem("email");
    window.location.reload();
    this.setState({ isLoggedIn: false });
  };

  render() {
    return (
      <nav className="NavbarItems">
        <h1 className="navbar-logo">Evolve-You</h1>

        <div className="menu-icons" onClick={this.handleClick}>
          <i
            className={this.state.clicked ? "fas fa-times" : "fas fa-bars"}
          ></i>
        </div>
        <ul className={this.state.clicked ? "nav-menu active" : "nav-menu"}>
          {MenuItems.map((item, index) => {
            return (
              <li key={index}>
                <NavLink
                  className={item.cName}
                  to={item.url}
                  activeClassName="active"
                >
                  <i className={item.icon}></i>
                  {item.title}
                </NavLink>
              </li>
            );
          })}
          {!this.state.isLoggedIn ? (
            <NavLink to="/login">
              <button className="signin" onClick={this.login}>
                Log-In
              </button>
            </NavLink>
          ) : (
            <>
              <NavLink to="/profile">
                <button className="profile-view" onClick={this.profile}>
                  My Profile
                </button>
              </NavLink>
              <NavLink to="/">
                <button className="logout" onClick={this.logout}>
                  Logout
                </button>
              </NavLink>
            </>
          )}
        </ul>
      </nav>
    );
  }
}

export default Navbar;

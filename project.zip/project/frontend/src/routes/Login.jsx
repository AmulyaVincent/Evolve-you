import Hero from "../Components/Hero";
import Navbar from "../Components/NavBar/Navbar";
import LoginImg from "../Assets/login2.jpg";
import Loginpage from "../Components/Loginpage";

function Login() {
  return (
    <>
      <Loginpage />
    </>
  );
}

export default Login;

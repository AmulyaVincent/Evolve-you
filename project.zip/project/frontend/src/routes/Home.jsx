import Navbar from "../Components/NavBar/Navbar";
import Hero from "../Components/Hero";
import HomeImg from "../Assets/1.jpg";
import Benefits from "../Components/Benefits";
import Workout from "../Components/workout";
import Footer from "../Components/Footer/Footer";
import Hlifestyle from "../Components/Hlifestyle";

function Home() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero"
        heroImg={HomeImg}
        title="Feel the Difference"
        text="Evolve you"
        buttonText="Explore"
        url="/workout"
        btnClass="show"
      />
      <Benefits />
      <Hlifestyle />
      <Workout />
      <Footer />
    </>
  );
}

export default Home;

import Hero from "../Components/Hero";
import Navbar from "../Components/NavBar/Navbar";
import Footer from "../Components/Footer/Footer";
import Videos from "../Components/Videos";
import WorkoutImg from "../Assets/bg10.jpg";
import Training from "../Components/Classes/Training";

function Workout() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={WorkoutImg}
        title="WORKOUTS"
        btnClass="hide"
      />
      <Training />
      <Videos />
      <Footer />
    </>
  );
}

export default Workout;

import Navbar from "../Components/NavBar/Navbar";
import Registerpage from "../Components/RegisterPage";

function Login() {
  return (
    <>
      <Registerpage />
    </>
  );
}

export default Login;

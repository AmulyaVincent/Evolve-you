import Hero from "../Components/Hero";
import Navbar from "../Components/NavBar/Navbar";
import ContactImg from "../Assets/contact4.jpg.jpg";
import Footer from "../Components/Footer/Footer";
import ContactForm from "../Components/Contact Form/ContactForm";

function contact() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        title="CONTACT US"
        heroImg={ContactImg}
        btnClass="hide"
      />
      <ContactForm />
      <Footer />
    </>
  );
}

export default contact;

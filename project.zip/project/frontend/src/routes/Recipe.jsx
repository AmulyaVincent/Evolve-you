import Hero from "../Components/Hero";
import Navbar from "../Components/NavBar/Navbar";
import ContactImg from "../Assets/recipebg.jpg";
import Footer from "../Components/Footer/Footer";
import RecipeItem from "../Components/recipes/RecipeItem";

function Recipes() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        title="RECIPES"
        heroImg={ContactImg}
        btnClass="hide"
      />
      <RecipeItem />
      <Footer />
    </>
  );
}

export default Recipes;

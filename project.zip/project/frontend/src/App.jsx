import React from "react";
import "./styles.css";
import { Route, Routes } from "react-router-dom";
import Home from "./routes/Home";
import Workout from "./routes/Workout";
import Recipe from "./routes/Recipe";
import Contact from "./routes/Contact";
import Login from "./routes/Login";
import Registerpage from "./routes/Register";
import PrivacyPolicy from "./Components/FooterLinks/PrivacyPolicy";
import Recipecards from "./Components/recipes/Recipecards";
import {Profile} from "./Components/Profile";
import Cookies from "./Components/FooterLinks/Cookies";
import Contactinfo from "./Components/FooterLinks/Contactinfo";
import TrainingCards from "./Components/Classes/Trainingcards";
import { NotFound } from "./Components/NotFound";

export default function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/workout" element={<Workout />} />
        <Route path="/recipes" element={<Recipe />} />
        <Route path="/Contactus" element={<Contact />} />
        <Route path="/recipe/:RecipeId" element={<Recipecards />} />
        <Route path="/workout/:CourseId" element={<TrainingCards />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Registerpage" element={<Registerpage />} />
        <Route path="/profile" element={<Profile />}/>
        <Route path="/PrivacyPolicy" element={<PrivacyPolicy />}/>
        <Route path="/Cookies" element={<Cookies />}/>
        <Route path="/Contactinfo" element={<Contactinfo />}/>
        <Route path="*" element={<NotFound />}/>
      </Routes>
    </div>
  );
}
